﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace responsi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private NpgsqlConnection conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=usti;Database=responsi");
        private string rID = "";

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                conn.Open();
                DataTable dt = new DataTable();
                NpgsqlCommand cmd = new NpgsqlCommand("SELECT * FROM dev_select()", conn);
                NpgsqlDataReader rd = cmd.ExecuteReader();
                dt.Load(rd);

                dgvData.DataSource = dt;

                dgvData.Columns["_id_dev"].HeaderText = "ID Developer";
                dgvData.Columns["_nama_dev"].HeaderText = "Nama Developer";
                dgvData.Columns["_status_kontrak"].HeaderText = "Status Kontrak";
                dgvData.Columns["_fitur_selesai"].HeaderText = "Fitur Selesai";
                dgvData.Columns["_jumlah_bug"].HeaderText = "Jumlah Bug";
                dgvData.Columns["_id_proyek"].HeaderText = "ID Proyek";
                dgvData.Columns["_nama_proyek"].HeaderText = "Nama Proyek";
                dgvData.Columns["_client"].HeaderText = "Client";
                dgvData.Columns["_budget"].HeaderText = "Budget";

                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Load Data: " + ex.Message);
                conn.Close();
            }
        }
    }
}
